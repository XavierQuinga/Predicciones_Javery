# JAVERY — Power BI Project con PostgreSQL Railway

Este proyecto PBIP utiliza DirectQuery sobre la tabla `public.predicciones`.

## Conexión ya configurada

- Servidor: `crossover.proxy.rlwy.net:42473`
- Base de datos: `railway`
- Modo: DirectQuery
- Tabla: `predicciones`

## Primer uso

1. Abre `JAVERY_Dashboard.pbip` en Power BI Desktop.
2. Cuando se soliciten credenciales, selecciona **Base de datos**.
3. Ingresa el usuario `postgres` y tu `PGPASSWORD` de Railway.
4. Conserva el cifrado/SSL habilitado.
5. Crea las visualizaciones desde la tabla `Predicciones` y guarda el proyecto.

Las contraseñas no se guardan en los archivos PBIP.
